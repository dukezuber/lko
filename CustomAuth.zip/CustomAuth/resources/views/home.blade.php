
@extends('layout.app')

@section('content')
home

@endsection
